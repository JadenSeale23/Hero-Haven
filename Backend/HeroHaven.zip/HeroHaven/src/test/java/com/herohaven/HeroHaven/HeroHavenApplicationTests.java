package com.herohaven.HeroHaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HeroHavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
